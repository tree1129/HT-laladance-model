const state = {
  actions: null,
  pressedKeys: new Set(),
  moveLoop: null,
  marchLoop: null,
  pointerHoldLoop: null,
  wakeAttempted: false,
  lastMoveSignature: "",
  marchPhase: 1,
};

const moveMap = {
  forward: { vx: 0.35, vy: 0.0, wz: 0.0 },
  backward: { vx: -0.28, vy: 0.0, wz: 0.0 },
  left: { vx: 0.0, vy: 0.28, wz: 0.0 },
  right: { vx: 0.0, vy: -0.28, wz: 0.0 },
  "turn-left": { vx: 0.0, vy: 0.0, wz: 1.2 },
  "turn-right": { vx: 0.0, vy: 0.0, wz: -1.2 },
  stop: { vx: 0.0, vy: 0.0, wz: 0.0 },
};

const keyMoveMap = {
  KeyW: "forward",
  KeyS: "backward",
  KeyA: "left",
  KeyD: "right",
  KeyQ: "turn-left",
  KeyE: "turn-right",
};

const localApiBase = window.location.protocol === "file:" ? "http://127.0.0.1:8765" : "";
const robotApiBase = "http://192.168.43.44:8766";
function log(message, data) {
  const el = document.getElementById("log-output");
  const stamp = new Date().toLocaleTimeString();
  const line = [`[${stamp}] ${message}`];
  if (data) {
    line.push(typeof data === "string" ? data : JSON.stringify(data, null, 2));
  }
  el.textContent = `${line.join("\n")}\n\n${el.textContent}`.trim();
}

async function requestJson(baseUrl, path, payload = null, method = "POST") {
  const options = { method, headers: {} };
  if (payload !== null) {
    options.headers["Content-Type"] = "application/json";
    options.body = JSON.stringify(payload);
  }
  const res = await fetch(`${baseUrl}${path}`, options);
  const data = await res.json();
  if (!res.ok || data.ok === false) {
    throw new Error(data.error || "请求失败");
  }
  return data;
}

async function api(path, payload = {}) {
  try {
    const result = await requestJson(robotApiBase, path, payload, "POST");
    setBridgeStatus("机器人端服务");
    return result;
  } catch (robotErr) {
    const result = await requestJson(localApiBase, path, payload, "POST");
    setBridgeStatus("本地SSH代理");
    return result;
  }
}

function renderActionList(containerId, items, categoryLabel) {
  const box = document.getElementById(containerId);
  box.innerHTML = "";
  items.forEach((item) => {
    const profiles = (state.actions?.production_profiles || [])
      .filter(Boolean)
      .flatMap((profile) => {
        const collections = [
          ...(profile.multi_waypoint_config || []),
          ...(profile.series_waypoint_config || []),
          ...(profile.policy_change_config || []),
        ];
        return collections
          .filter((entry) => entry.name === item.name && entry.key)
          .map((entry) => ({ productionType: profile.production_type, key: entry.key }));
      });

    const btn = document.createElement("button");
    btn.className = "action-btn";
    const keyTags = profiles.length
      ? `<div class="action-meta">${profiles.map((profile) => `<span class="action-key" title="${profile.productionType}">${profile.key}</span>`).join("")}</div>`
      : "";
    btn.innerHTML = `
      <strong>${item.name}</strong>
      <span>${item.remark || categoryLabel}</span>
      ${keyTags}
    `;
    btn.addEventListener("click", async () => {
      try {
        document.getElementById("status-text").textContent = `执行 ${item.name}`;
        const result = await api("/api/action", { name: item.name });
        document.getElementById("status-text").textContent = "动作已发送";
        log(`动作已发送: ${item.name}`, result);
      } catch (err) {
        document.getElementById("status-text").textContent = "动作发送失败";
        log(`动作失败: ${item.name}`, err.message);
      }
    });
    box.appendChild(btn);
  });
}

async function loadConfig() {
  let data;
  try {
    data = await requestJson(robotApiBase, "/api/config", null, "GET");
    setBridgeStatus("机器人端服务");
  } catch (robotErr) {
    const res = await fetch(`${localApiBase}/api/config`);
    data = await res.json();
    setBridgeStatus("本地SSH代理");
  }
  state.actions = data.actions;
  document.getElementById("robot-host").textContent = data.robot.host;
  document.getElementById("robot-user").textContent = data.robot.user;

  const policy = data.actions.policy_change_config || [];
  const waypoint = data.actions.multi_waypoint_config || [];
  const series = data.actions.series_waypoint_config || [];

  document.getElementById("action-count").textContent = String(policy.length + waypoint.length + series.length);
  renderActionList("policy-list", policy, "策略动作");
  renderActionList("waypoint-list", waypoint, "单段动作");
  renderActionList("series-list", series, "串联动作");
  log("动作库已加载", data.actions.production_profiles);
}

async function move(kind) {
  const cfg = moveMap[kind];
  try {
    if (kind !== "stop" && !state.wakeAttempted) {
      await wakeRobot();
    }
    const result = await sendCmdVel(kind === "stop" ? moveMap.stop : cfg);
    document.getElementById("status-text").textContent = `已发送 ${kind}`;
    log(`方向控制: ${kind}`, result);
  } catch (err) {
    document.getElementById("status-text").textContent = "控制失败";
    log(`方向控制失败: ${kind}`, err.message);
  }
}

async function wakeRobot() {
  try {
    const result = await api("/api/wake");
    state.wakeAttempted = true;
    setStatus("已尝试激活移动模式");
    log("已发送激活移动模式", result);
    return result;
  } catch (err) {
    setStatus("激活移动模式失败");
    log("激活移动模式失败", err.message);
    throw err;
  }
}

async function runChoreography() {
  try {
    setStatus("执行双手欢呼、踏步、前后右移编排中");
    const result = await api("/api/choreography");
    setStatus("编排执行完成");
    log("编排执行完成", result);
  } catch (err) {
    setStatus("编排执行失败");
    log("编排执行失败", err.message);
  }
}

async function runNamedAction(name, label = name) {
  try {
    setStatus(`执行 ${label}`);
    const result = await api("/api/action", { name });
    setStatus(`${label}已发送`);
    log(`动作已发送: ${label}`, result);
  } catch (err) {
    setStatus(`${label}发送失败`);
    log(`动作失败: ${label}`, err.message);
  }
}

function setStatus(text) {
  document.getElementById("status-text").textContent = text;
}

function getCurrentVector() {
  let vx = 0.0;
  let vy = 0.0;
  let wz = 0.0;

  if (state.pressedKeys.has("KeyW")) vx += moveMap.forward.vx;
  if (state.pressedKeys.has("KeyS")) vx += moveMap.backward.vx;
  if (state.pressedKeys.has("KeyA")) vy += moveMap.left.vy;
  if (state.pressedKeys.has("KeyD")) vy += moveMap.right.vy;
  if (state.pressedKeys.has("KeyQ")) wz += moveMap["turn-left"].wz;
  if (state.pressedKeys.has("KeyE")) wz += moveMap["turn-right"].wz;

  vx = Math.max(-0.35, Math.min(0.35, vx));
  vy = Math.max(-0.28, Math.min(0.28, vy));
  wz = Math.max(-1.2, Math.min(1.2, wz));

  return { vx, vy, wz };
}

async function sendVector(vector, reason) {
  const signature = JSON.stringify(vector);
  if (signature === state.lastMoveSignature) return;
  state.lastMoveSignature = signature;

  try {
    const result = await sendCmdVel(vector);
    setStatus(reason);
    log(`键盘控制: ${reason}`, result);
  } catch (err) {
    setStatus("键盘控制失败");
    state.lastMoveSignature = "";
    log(`键盘控制失败: ${reason}`, err.message);
  }
}

function setBridgeStatus(text) {
  const el = document.getElementById("bridge-status");
  if (el) el.textContent = text;
}

async function sendCmdVel(vector) {
  const result = (vector.vx === 0 && vector.vy === 0 && vector.wz === 0)
    ? await api("/api/stop")
    : await api("/api/move", { ...vector, duration: 0.42, interval: 0.05 });
  return { transport: "joy_input", result };
}

function stopMoveLoop() {
  if (state.moveLoop) {
    clearInterval(state.moveLoop);
    state.moveLoop = null;
  }
}

function stopMarchLoop() {
  if (state.marchLoop) {
    clearInterval(state.marchLoop);
    state.marchLoop = null;
  }
  const btn = document.getElementById("march-btn");
  if (btn) btn.classList.remove("active");
}

function refreshMoveLoop() {
  stopMoveLoop();
  const activeKeys = Object.keys(keyMoveMap).filter((code) => state.pressedKeys.has(code));
  if (!activeKeys.length) {
    state.lastMoveSignature = "";
    sendVector({ vx: 0.0, vy: 0.0, wz: 0.0 }, "停止");
    return;
  }

  const tick = () => {
    const vector = getCurrentVector();
    sendVector(vector, `键盘移动 ${activeKeys.map((code) => keyMoveMap[code]).join("+")}`);
  };
  tick();
  state.moveLoop = setInterval(tick, 120);
}

function toggleMarchMode() {
  if (state.marchLoop) {
    stopMarchLoop();
    state.lastMoveSignature = "";
    sendVector({ vx: 0.0, vy: 0.0, wz: 0.0 }, "停止原地踏步");
    setStatus("原地踏步已停止");
    return;
  }

  stopMoveLoop();
  state.pressedKeys.clear();
  state.marchPhase = 1;
  const btn = document.getElementById("march-btn");
  if (btn) btn.classList.add("active");

  const tick = () => {
    const vector = {
      vx: 0.05,
      vy: 0.0,
      wz: state.marchPhase > 0 ? 0.6 : -0.6,
    };
    state.marchPhase *= -1;
    state.lastMoveSignature = "";
    sendVector(vector, "原地踏步");
  };

  tick();
  state.marchLoop = setInterval(tick, 260);
  setStatus("原地踏步中");
}

function stopPointerHoldLoop(sendStop = true) {
  if (state.pointerHoldLoop) {
    clearInterval(state.pointerHoldLoop);
    state.pointerHoldLoop = null;
  }
  if (sendStop) {
    state.lastMoveSignature = "";
    sendVector({ vx: 0.0, vy: 0.0, wz: 0.0 }, "停止");
  }
}

async function startPointerHold(kind) {
  if (kind === "stop" || kind === "march-toggle") return;
  stopMarchLoop();
  stopPointerHoldLoop(false);
  if (!state.wakeAttempted) {
    await wakeRobot();
  }
  const vector = moveMap[kind];
  const tick = () => {
    state.lastMoveSignature = "";
    sendVector(vector, `按住控制 ${kind}`);
  };
  tick();
  state.pointerHoldLoop = setInterval(tick, 120);
}

function normalizeKeyCode(event) {
  if (event.code === "Space") return "Space";
  if (event.code === "KeyR") return "KeyR";
  if (event.code === "KeyC") return "KeyC";
  return keyMoveMap[event.code] ? event.code : "";
}

function bindKeyboard() {
  window.addEventListener("keydown", (event) => {
    const code = normalizeKeyCode(event);
    if (!code) return;
    if (["INPUT", "TEXTAREA", "SELECT"].includes(document.activeElement?.tagName)) return;

    event.preventDefault();
    if (code === "Space") {
      state.pressedKeys.clear();
      stopMoveLoop();
      stopMarchLoop();
      state.lastMoveSignature = "";
      sendVector({ vx: 0.0, vy: 0.0, wz: 0.0 }, "急停");
      setStatus("急停");
      return;
    }
    if (code === "KeyR" && !event.repeat) {
      toggleMarchMode();
      return;
    }
    if (code === "KeyC" && !event.repeat) {
      runNamedAction("cheer", "双手欢呼");
      return;
    }

    if (state.marchLoop) stopMarchLoop();
    state.pressedKeys.add(code);
    refreshMoveLoop();
  });

  window.addEventListener("keyup", (event) => {
    const code = normalizeKeyCode(event);
    if (!code || code === "Space" || code === "KeyR" || code === "KeyC") return;
    state.pressedKeys.delete(code);
    refreshMoveLoop();
  });

  window.addEventListener("blur", () => {
    state.pressedKeys.clear();
    stopMoveLoop();
    stopMarchLoop();
    stopPointerHoldLoop(false);
    state.lastMoveSignature = "";
    sendVector({ vx: 0.0, vy: 0.0, wz: 0.0 }, "窗口失焦自动停止");
  });
}

function bindEvents() {
  document.querySelectorAll("[data-move]").forEach((btn) => {
    btn.addEventListener("click", () => {
      if (btn.dataset.move === "march-toggle") {
        toggleMarchMode();
        return;
      }
      if (btn.dataset.move === "stop") {
        stopPointerHoldLoop(false);
        move("stop");
      }
    });

    if (btn.dataset.move && !["stop", "march-toggle"].includes(btn.dataset.move)) {
      btn.addEventListener("mousedown", () => startPointerHold(btn.dataset.move));
      btn.addEventListener("mouseup", () => stopPointerHoldLoop());
      btn.addEventListener("mouseleave", () => stopPointerHoldLoop());
      btn.addEventListener("touchstart", (event) => {
        event.preventDefault();
        startPointerHold(btn.dataset.move);
      }, { passive: false });
      btn.addEventListener("touchend", () => stopPointerHoldLoop());
      btn.addEventListener("touchcancel", () => stopPointerHoldLoop());
    }
  });
  document.getElementById("stop-btn").addEventListener("click", () => move("stop"));
  document.getElementById("wake-btn").addEventListener("click", () => wakeRobot());
  document.getElementById("choreo-btn").addEventListener("click", () => runChoreography());
  document.getElementById("cheer-btn").addEventListener("click", () => runNamedAction("cheer", "双手欢呼"));
}

bindEvents();
bindKeyboard();
setBridgeStatus("Joy模式");
loadConfig().catch((err) => {
  setStatus("初始化失败");
  log("初始化失败", err.message);
});
