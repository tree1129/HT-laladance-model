const state = {
  actions: null,
  pressedKeys: new Set(),
  moveLoop: null,
  marchLoop: null,
  pointerHoldLoop: null,
  wakeAttempted: false,
  lastMoveSignature: "",
  marchPhase: 1,
};

const moveMap = {
  forward: { vx: 0.35, vy: 0.0, wz: 0.0 },
  backward: { vx: -0.28, vy: 0.0, wz: 0.0 },
  left: { vx: 0.0, vy: 0.28, wz: 0.0 },
  right: { vx: 0.0, vy: -0.28, wz: 0.0 },
  "turn-left": { vx: 0.0, vy: 0.0, wz: 1.2 },
  "turn-right": { vx: 0.0, vy: 0.0, wz: -1.2 },
  stop: { vx: 0.0, vy: 0.0, wz: 0.0 },
};

const keyMoveMap = {
  KeyW: "forward",
  KeyS: "backward",
  KeyA: "left",
  KeyD: "right",
  KeyQ: "turn-left",
  KeyE: "turn-right",
};

function log(message, data) {
  const el = document.getElementById("log-output");
  const stamp = new Date().toLocaleTimeString();
  const line = [`[${stamp}] ${message}`];
  if (data) {
    line.push(typeof data === "string" ? data : JSON.stringify(data, null, 2));
  }
  el.textContent = `${line.join("\n")}\n\n${el.textContent}`.trim();
}

async function requestJson(path, payload = null, method = "POST") {
  const options = { method, headers: {} };
  if (payload !== null) {
    options.headers["Content-Type"] = "application/json";
    options.body = JSON.stringify(payload);
  }
  const res = await fetch(path, options);
  const data = await res.json();
  if (!res.ok || data.ok === false) throw new Error(data.error || "请求失败");
  return data;
}

async function api(path, payload = {}) {
  return requestJson(path, payload, "POST");
}

function setStatus(text) {
  document.getElementById("status-text").textContent = text;
}

function setBridgeStatus(text) {
  document.getElementById("bridge-status").textContent = text;
}

function actionProfiles(itemName) {
  return (state.actions?.production_profiles || [])
    .filter(Boolean)
    .flatMap((profile) => {
      const groups = [
        ...(profile.multi_waypoint_config || []),
        ...(profile.series_waypoint_config || []),
        ...(profile.policy_change_config || []),
      ];
      return groups
        .filter((entry) => entry.name === itemName && entry.key)
        .map((entry) => ({ productionType: profile.production_type, key: entry.key }));
    });
}

function renderActionList(containerId, items, categoryLabel) {
  const box = document.getElementById(containerId);
  box.innerHTML = "";
  items.forEach((item) => {
    const profiles = actionProfiles(item.name);
    const keyTags = profiles.length
      ? `<div class="action-meta">${profiles.map((profile) => `<span class="action-key" title="${profile.productionType}">${profile.key}</span>`).join("")}</div>`
      : "";
    const btn = document.createElement("button");
    btn.className = "action-btn";
    btn.innerHTML = `
      <strong>${item.name}</strong>
      <span>${item.remark || categoryLabel}</span>
      ${keyTags}
    `;
    btn.addEventListener("click", async () => {
      try {
        setStatus(`执行 ${item.name}`);
        const result = await api("/api/action", { name: item.name });
        setStatus("动作已发送");
        log(`动作已发送: ${item.name}`, result);
      } catch (err) {
        setStatus("动作发送失败");
        log(`动作失败: ${item.name}`, err.message);
      }
    });
    box.appendChild(btn);
  });
}

async function loadConfig() {
  const data = await requestJson("/api/config", null, "GET");
  state.actions = data.actions;
  document.getElementById("action-count").textContent = String(
    (data.actions.policy_change_config || []).length +
    (data.actions.multi_waypoint_config || []).length +
    (data.actions.series_waypoint_config || []).length
  );
  renderActionList("policy-list", data.actions.policy_change_config || [], "策略动作");
  renderActionList("waypoint-list", data.actions.multi_waypoint_config || [], "单段动作");
  renderActionList("series-list", data.actions.series_waypoint_config || [], "串联动作");
  setBridgeStatus("Robot Local");
  log("动作库已加载", data.actions.production_profiles);
}

async function wakeRobot() {
  const result = await api("/api/wake");
  state.wakeAttempted = true;
  setStatus("已尝试激活移动模式");
  log("已发送激活移动模式", result);
  return result;
}

async function runChoreography() {
  try {
    setStatus("编排执行中");
    const result = await api("/api/choreography");
    setStatus("编排执行完成");
    log("编排执行完成", result);
  } catch (err) {
    setStatus("编排执行失败");
    log("编排执行失败", err.message);
  }
}

async function runNamedAction(name, label = name) {
  try {
    setStatus(`执行 ${label}`);
    const result = await api("/api/action", { name });
    setStatus(`${label}已发送`);
    log(`动作已发送: ${label}`, result);
  } catch (err) {
    setStatus(`${label}发送失败`);
    log(`动作失败: ${label}`, err.message);
  }
}

function getCurrentVector() {
  let vx = 0.0, vy = 0.0, wz = 0.0;
  if (state.pressedKeys.has("KeyW")) vx += moveMap.forward.vx;
  if (state.pressedKeys.has("KeyS")) vx += moveMap.backward.vx;
  if (state.pressedKeys.has("KeyA")) vy += moveMap.left.vy;
  if (state.pressedKeys.has("KeyD")) vy += moveMap.right.vy;
  if (state.pressedKeys.has("KeyQ")) wz += moveMap["turn-left"].wz;
  if (state.pressedKeys.has("KeyE")) wz += moveMap["turn-right"].wz;
  return {
    vx: Math.max(-0.35, Math.min(0.35, vx)),
    vy: Math.max(-0.28, Math.min(0.28, vy)),
    wz: Math.max(-1.2, Math.min(1.2, wz)),
  };
}

async function sendCmd(vector) {
  return (vector.vx === 0 && vector.vy === 0 && vector.wz === 0)
    ? api("/api/stop")
    : api("/api/move", { ...vector, repeat: 8 });
}

async function sendVector(vector, reason) {
  const signature = JSON.stringify(vector);
  if (signature === state.lastMoveSignature) return;
  state.lastMoveSignature = signature;
  try {
    const result = await sendCmd(vector);
    setStatus(reason);
    log(`运动控制: ${reason}`, result);
  } catch (err) {
    state.lastMoveSignature = "";
    setStatus("控制失败");
    log(`控制失败: ${reason}`, err.message);
  }
}

function stopMoveLoop() {
  if (state.moveLoop) clearInterval(state.moveLoop);
  state.moveLoop = null;
}

function stopMarchLoop() {
  if (state.marchLoop) clearInterval(state.marchLoop);
  state.marchLoop = null;
  document.getElementById("march-btn")?.classList.remove("active");
}

function stopPointerHoldLoop(sendStop = true) {
  if (state.pointerHoldLoop) clearInterval(state.pointerHoldLoop);
  state.pointerHoldLoop = null;
  if (sendStop) {
    state.lastMoveSignature = "";
    sendVector({ vx: 0.0, vy: 0.0, wz: 0.0 }, "停止");
  }
}

function refreshMoveLoop() {
  stopMoveLoop();
  const activeKeys = Object.keys(keyMoveMap).filter((code) => state.pressedKeys.has(code));
  if (!activeKeys.length) {
    state.lastMoveSignature = "";
    sendVector({ vx: 0.0, vy: 0.0, wz: 0.0 }, "停止");
    return;
  }
  const tick = () => sendVector(getCurrentVector(), `键盘移动 ${activeKeys.map((code) => keyMoveMap[code]).join("+")}`);
  tick();
  state.moveLoop = setInterval(tick, 120);
}

function toggleMarchMode() {
  if (state.marchLoop) {
    stopMarchLoop();
    state.lastMoveSignature = "";
    sendVector({ vx: 0.0, vy: 0.0, wz: 0.0 }, "停止原地踏步");
    setStatus("原地踏步已停止");
    return;
  }
  stopMoveLoop();
  state.pressedKeys.clear();
  state.marchPhase = 1;
  document.getElementById("march-btn")?.classList.add("active");
  const tick = () => {
    const vector = { vx: 0.05, vy: 0.0, wz: state.marchPhase > 0 ? 0.6 : -0.6 };
    state.marchPhase *= -1;
    state.lastMoveSignature = "";
    sendVector(vector, "原地踏步");
  };
  tick();
  state.marchLoop = setInterval(tick, 260);
  setStatus("原地踏步中");
}

async function startPointerHold(kind) {
  if (kind === "stop" || kind === "march-toggle") return;
  stopMarchLoop();
  stopPointerHoldLoop(false);
  if (!state.wakeAttempted) await wakeRobot();
  const vector = moveMap[kind];
  const tick = () => {
    state.lastMoveSignature = "";
    sendVector(vector, `按住控制 ${kind}`);
  };
  tick();
  state.pointerHoldLoop = setInterval(tick, 120);
}

function normalizeKeyCode(event) {
  if (event.code === "Space") return "Space";
  if (event.code === "KeyR") return "KeyR";
  if (event.code === "KeyC") return "KeyC";
  return keyMoveMap[event.code] ? event.code : "";
}

function bindKeyboard() {
  window.addEventListener("keydown", async (event) => {
    const code = normalizeKeyCode(event);
    if (!code) return;
    event.preventDefault();
    if (code === "Space") {
      state.pressedKeys.clear();
      stopMoveLoop();
      stopMarchLoop();
      stopPointerHoldLoop(false);
      state.lastMoveSignature = "";
      sendVector({ vx: 0.0, vy: 0.0, wz: 0.0 }, "急停");
      setStatus("急停");
      return;
    }
    if (code === "KeyR" && !event.repeat) {
      toggleMarchMode();
      return;
    }
    if (code === "KeyC" && !event.repeat) {
      runNamedAction("cheer", "双手欢呼");
      return;
    }
    if (!state.wakeAttempted) await wakeRobot();
    if (state.marchLoop) stopMarchLoop();
    state.pressedKeys.add(code);
    refreshMoveLoop();
  });

  window.addEventListener("keyup", (event) => {
    const code = normalizeKeyCode(event);
    if (!code || code === "Space" || code === "KeyR" || code === "KeyC") return;
    state.pressedKeys.delete(code);
    refreshMoveLoop();
  });

  window.addEventListener("blur", () => {
    state.pressedKeys.clear();
    stopMoveLoop();
    stopMarchLoop();
    stopPointerHoldLoop(false);
    state.lastMoveSignature = "";
    sendVector({ vx: 0.0, vy: 0.0, wz: 0.0 }, "窗口失焦自动停止");
  });
}

function bindEvents() {
  document.querySelectorAll("[data-move]").forEach((btn) => {
    btn.addEventListener("click", () => {
      if (btn.dataset.move === "march-toggle") return toggleMarchMode();
      if (btn.dataset.move === "stop") {
        stopPointerHoldLoop(false);
        sendVector({ vx: 0.0, vy: 0.0, wz: 0.0 }, "停止");
      }
    });
    if (btn.dataset.move && !["stop", "march-toggle"].includes(btn.dataset.move)) {
      btn.addEventListener("mousedown", () => startPointerHold(btn.dataset.move));
      btn.addEventListener("mouseup", () => stopPointerHoldLoop());
      btn.addEventListener("mouseleave", () => stopPointerHoldLoop());
      btn.addEventListener("touchstart", (event) => { event.preventDefault(); startPointerHold(btn.dataset.move); }, { passive: false });
      btn.addEventListener("touchend", () => stopPointerHoldLoop());
      btn.addEventListener("touchcancel", () => stopPointerHoldLoop());
    }
  });
  document.getElementById("wake-btn").addEventListener("click", () => wakeRobot());
  document.getElementById("stop-btn").addEventListener("click", () => sendVector({ vx: 0.0, vy: 0.0, wz: 0.0 }, "急停"));
  document.getElementById("choreo-btn").addEventListener("click", () => runChoreography());
  document.getElementById("cheer-btn").addEventListener("click", () => runNamedAction("cheer", "双手欢呼"));
}

bindEvents();
bindKeyboard();
loadConfig().catch((err) => {
  setStatus("初始化失败");
  log("初始化失败", err.message);
});
